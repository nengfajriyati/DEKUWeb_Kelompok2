

<?php $__env->startSection('page-title', 'Tambah Reminder'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('reminder.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label>Judul Reminder</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Tanggal Pengingat</label>
                    <input type="date" name="remind_date" class="form-control" required>
                </div>

                <button class="btn btn-warning">Simpan</button>
                <a href="<?php echo e(route('reminder.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/reminder/create.blade.php ENDPATH**/ ?>