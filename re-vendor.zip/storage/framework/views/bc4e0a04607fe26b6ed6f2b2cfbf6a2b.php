<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <h4>💸 Pengeluaran</h4>
        <a href="<?php echo e(route('expense.create')); ?>" class="btn btn-danger">
            <i class="bi bi-plus-circle"></i> Tambah Pengeluaran
        </a>
    </div>

    <?php if(session('success')): ?>
        <script>
            Swal.fire('Berhasil!', '<?php echo e(session('success')); ?>', 'success');
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire('Gagal!', '<?php echo e(session('error')); ?>', 'error');
        </script>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Dompet</th>
                        <th>Nominal</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($expense->created_at->format('d M Y')); ?></td>
                            <td><?php echo e($expense->wallet->name ?? '-'); ?></td>
                            <td class="text-danger fw-bold">
                                - Rp <?php echo e(number_format($expense->amount,0,',','.')); ?>

                            </td>
                            <td><?php echo e($expense->description ?? '-'); ?></td>
                            <td>
                                <a href="<?php echo e(route('expense.edit',$expense->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>

                                <form action="<?php echo e(route('expense.destroy',$expense->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger btn-delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada pengeluaran</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'Yakin?',
            text: 'Data akan dihapus!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, hapus',
        }).then((result) => {
            if (result.isConfirmed) {
                this.closest('form').submit();
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/expense/index.blade.php ENDPATH**/ ?>