<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?> - DEKU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #4cc9f0, #4361ee);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .auth-card {
            width: 400px;
            border-radius: 14px;
            background: white;
            padding: 30px;
        }
    </style>
</head>
<body>

<div class="auth-card shadow">
    <h3 class="text-center fw-bold"><?php echo $__env->yieldContent('title'); ?></h3>
    <p class="text-center text-muted"><?php echo $__env->yieldContent('subtitle'); ?></p>
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/layouts/auth.blade.php ENDPATH**/ ?>