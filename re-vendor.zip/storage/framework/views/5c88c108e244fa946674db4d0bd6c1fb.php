<?php $__env->startSection('page-title', 'Pemasukan'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Berhasil',
    text: '<?php echo e(session('success')); ?>',
    timer: 2000,
    showConfirmButton: false
});
</script>
<?php endif; ?>

<div class="card">
    <div class="card-body">

        <a href="<?php echo e(route('income.create')); ?>" class="btn btn-primary mb-3">
            <i class="bi bi-plus-circle"></i> Tambah Pemasukan
        </a>

        <table class="table table-hover align-middle">
            <thead class="table-light text-center">
                <tr>
                    <th width="50">No</th>
                    <th>Tanggal</th>
                    <th>Dompet</th>
                    <th>Keterangan</th>
                    <th>Nominal</th>
                    <th width="130">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center">
                        <?php echo e($loop->iteration); ?>

                    </td>

                    <td>
                        <i class="bi bi-calendar-event text-primary"></i>
                        <?php echo e($income->created_at->format('d M Y')); ?>

                    </td>

                    <td>
                        <i class="bi bi-wallet2 text-secondary"></i>
                        <?php echo e($income->wallet->name ?? '-'); ?>

                    </td>

                    <td>
                        <?php echo e($income->description); ?>

                    </td>

                    <td class="text-success fw-semibold">
                        <i class="bi bi-arrow-up-circle"></i>
                        Rp <?php echo e(number_format($income->amount,0,',','.')); ?>

                    </td>

                    <td class="text-center">
                        <a href="<?php echo e(route('income.edit',$income->id)); ?>"
                        class="btn btn-warning btn-sm"
                        title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>

                        <button class="btn btn-danger btn-sm"
                            onclick="hapus(<?php echo e($income->id); ?>)"
                            title="Hapus">
                            <i class="bi bi-trash-fill"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-3">
                        <i class="bi bi-inbox"></i> Belum ada pemasukan
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>


    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function hapus(id){
    Swal.fire({
        title: 'Yakin hapus?',
        text: 'Data tidak bisa dikembalikan',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if(result.isConfirmed){
            document.getElementById('hapus-'+id).submit();
        }
    });
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/income/index.blade.php ENDPATH**/ ?>