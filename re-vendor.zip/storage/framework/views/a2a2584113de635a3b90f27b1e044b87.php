<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="fw-bold mb-4">✏️ Edit Pemasukan</h4>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form action="<?php echo e(route('income.update', $income->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">Dompet</label>
                    <select name="wallet_id" class="form-select" required>
                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($wallet->id); ?>" <?php echo e($income->wallet_id == $wallet->id ? 'selected' : ''); ?>>
                                <?php echo e($wallet->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="amount" class="form-control" min="1" value="<?php echo e($income->amount); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="date" class="form-control" value="<?php echo e($income->date); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Keterangan</label>
                    <input type="text" name="description" class="form-control" value="<?php echo e($income->description); ?>">
                </div>

                <button class="btn btn-warning">💾 Update</button>
                <a href="<?php echo e(route('income.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/income/edit.blade.php ENDPATH**/ ?>