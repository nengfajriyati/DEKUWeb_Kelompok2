

<?php $__env->startSection('page-title', 'Goals'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-semibold">
            <i class="bi bi-bullseye text-primary me-1"></i> Goals
        </h4>
        <a href="<?php echo e(route('goal.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i> Tambah Goal
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="50" class="text-center">No</th>
                        <th>
                            <i class="bi bi-card-text me-1"></i> Judul
                        </th>
                        <th>
                            <i class="bi bi-cash-stack me-1"></i> Target
                        </th>
                        <th>
                            <i class="bi bi-calendar-event me-1"></i> Deadline
                        </th>
                        <th width="140" class="text-center">
                            <i class="bi bi-gear me-1"></i> Aksi
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center fw-semibold">
                            <?php echo e($loop->iteration); ?>

                        </td>
                        <td><?php echo e($goal->title); ?></td>
                        <td>
                            Rp <?php echo e(number_format($goal->target_amount,0,',','.')); ?>

                        </td>
                        <td>
                            <?php echo e($goal->deadline ? date('d M Y', strtotime($goal->deadline)) : '-'); ?>

                        </td>
                        <td class="text-center">

                            <a href="<?php echo e(route('goal.edit', $goal->id)); ?>"
                               class="btn btn-warning btn-sm me-1"
                               title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                            <form action="<?php echo e(route('goal.destroy', $goal->id)); ?>"
                                  method="POST"
                                  class="d-inline delete-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="button"
                                        class="btn btn-danger btn-sm btn-delete"
                                        title="Hapus">
                                    <i class="bi bi-trash3"></i>
                                </button>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                            Belum ada goal
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php if(session('success')): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Berhasil',
    text: '<?php echo e(session('success')); ?>',
    timer: 2000,
    showConfirmButton: false
});
</script>
<?php endif; ?>


<script>
document.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', function () {
        Swal.fire({
            title: 'Yakin?',
            text: 'Goal ini akan dihapus permanen!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                this.closest('form').submit();
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/goal/index.blade.php ENDPATH**/ ?>