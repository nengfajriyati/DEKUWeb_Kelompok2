

<?php $__env->startSection('page-title', 'Edit Goal'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('goal.update', $goal->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label>Judul</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($goal->title); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Target Nominal</label>
                    <input type="number" name="target_amount" class="form-control"
                           value="<?php echo e($goal->target_amount); ?>" min="1" required>
                </div>

                <div class="mb-3">
                    <label>Deadline</label>
                    <input type="date" name="deadline" class="form-control"
                           value="<?php echo e($goal->deadline); ?>">
                </div>

                <button class="btn btn-warning">Update</button>
                <a href="<?php echo e(route('goal.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/goal/edit.blade.php ENDPATH**/ ?>