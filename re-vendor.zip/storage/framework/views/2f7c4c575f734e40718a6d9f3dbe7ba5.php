<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-3">➖ Tambah Pengeluaran</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('expense.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label>Dompet</label>
                    <select name="wallet_id" class="form-select" required>
                        <option value="">-- Pilih Dompet --</option>
                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($wallet->id); ?>">
                                <?php echo e($wallet->name); ?> (Rp <?php echo e(number_format($wallet->balance,0,',','.')); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                <div class="mb-3">
                    <label>Nominal</label>
                    <input 
                        type="number" 
                        name="amount" 
                        class="form-control" 
                        min="1"
                        step="1"
                        onkeydown="return event.key !== '+'"
                        required
                    >
                </div>

                </div>

                <div class="mb-3">
                    <label>Deskripsi</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>

                <button class="btn btn-danger">
                    <i class="bi bi-save"></i> Simpan
                </button>
                <a href="<?php echo e(route('expense.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/expense/create.blade.php ENDPATH**/ ?>