<?php $__env->startSection('page-title', 'Tambah Pemasukan'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">

        <form action="<?php echo e(route('income.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label>Dompet</label>
                <select name="wallet_id" class="form-control" required>
                    <option value="">-- Pilih Dompet --</option>
                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($wallet->id); ?>">
                            <?php echo e($wallet->name); ?> (Rp <?php echo e(number_format($wallet->balance)); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Nominal</label>
                <input type="number" name="amount" min="1" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Keterangan</label>
                <input type="text" name="description" class="form-control" required>
            </div>

            <button class="btn btn-success">
                <i class="bi bi-save"></i> Simpan
            </button>

            <a href="<?php echo e(route('income.index')); ?>" class="btn btn-secondary">
                Kembali
            </a>

        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/income/create.blade.php ENDPATH**/ ?>