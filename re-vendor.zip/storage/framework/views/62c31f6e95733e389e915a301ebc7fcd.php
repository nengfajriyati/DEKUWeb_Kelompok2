

<?php $__env->startSection('page-title', 'Edit Pemasukan'); ?>

<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Gagal',
        text: '<?php echo e($errors->first()); ?>'
    });
</script>
<?php endif; ?>

<div class="container">
    <div class="card shadow-sm border-0">
        <div class="card-body">

            <h4 class="fw-bold mb-4">
                <i class="bi bi-pencil-square text-warning me-2"></i>
                Edit Data Pemasukan
            </h4>

            <form action="<?php echo e(route('income.update', $income->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Dompet</label>
                    <select name="wallet_id" class="form-select" required>
                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($wallet->id); ?>"
                                <?php echo e($income->wallet_id == $wallet->id ? 'selected' : ''); ?>>
                                <?php echo e($wallet->name); ?>

                                (Rp <?php echo e(number_format($wallet->balance,0,',','.')); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nominal</label>
                    <input type="number"
                           name="amount"
                           class="form-control"
                           min="1"
                           value="<?php echo e($income->amount); ?>"
                           required>
                </div>

                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tanggal</label>
                    <input type="date"
                           name="date"
                           class="form-control"
                           value="<?php echo e($income->date); ?>"
                           required>
                </div>

                
                <div class="mb-4">
                    <label class="form-label fw-semibold">Deskripsi</label>
                    <textarea name="description"
                              class="form-control"
                              rows="3"><?php echo e($income->description); ?></textarea>
                </div>

                
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(route('income.index')); ?>" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>

                    <button class="btn btn-warning text-white">
                        <i class="bi bi-save"></i> Update
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\DekuWeb_Kelompok2\resources\views/wallet/edit.blade.php ENDPATH**/ ?>