@extends('layouts.admin')

@section('page-title', 'Edit Pemasukan')

@section('content')

{{-- ALERT VALIDATION --}}
@if ($errors->any())
<script>
    Swal.fire({
        icon: 'error',
        title: 'Gagal',
        text: '{{ $errors->first() }}'
    });
</script>
@endif

<div class="container">
    <div class="card shadow-sm border-0">
        <div class="card-body">

            <h4 class="fw-bold mb-4">
                <i class="bi bi-pencil-square text-warning me-2"></i>
                Edit Data Pemasukan
            </h4>

            <form action="{{ route('income.update', $income->id) }}" method="POST">
                @csrf
                @method('PUT')

                {{-- DOMPET --}}
                <div class="mb-3">
                    <label class="form-label fw-semibold">Dompet</label>
                    <select name="wallet_id" class="form-select" required>
                        @foreach($wallets as $wallet)
                            <option value="{{ $wallet->id }}"
                                {{ $income->wallet_id == $wallet->id ? 'selected' : '' }}>
                                {{ $wallet->name }}
                                (Rp {{ number_format($wallet->balance,0,',','.') }})
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- NOMINAL --}}
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nominal</label>
                    <input type="number"
                           name="amount"
                           class="form-control"
                           min="1"
                           value="{{ $income->amount }}"
                           required>
                </div>

                {{-- TANGGAL --}}
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tanggal</label>
                    <input type="date"
                           name="date"
                           class="form-control"
                           value="{{ $income->date }}"
                           required>
                </div>

                {{-- DESKRIPSI --}}
                <div class="mb-4">
                    <label class="form-label fw-semibold">Deskripsi</label>
                    <textarea name="description"
                              class="form-control"
                              rows="3">{{ $income->description }}</textarea>
                </div>

                {{-- BUTTON --}}
                <div class="d-flex justify-content-between">
                    <a href="{{ route('income.index') }}" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>

                    <button class="btn btn-warning text-white">
                        <i class="bi bi-save"></i> Update
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

{{-- SWEETALERT --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

@endsection
