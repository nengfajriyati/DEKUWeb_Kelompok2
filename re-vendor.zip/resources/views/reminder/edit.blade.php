@extends('layouts.admin')

@section('page-title', 'Edit Reminder')

@section('content')
<div class="container">
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="{{ route('reminder.update', $reminder->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-3">
                    <label>Judul Reminder</label>
                    <input type="text" name="title"
                           value="{{ $reminder->title }}"
                           class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Tanggal Pengingat</label>
                    <input type="date" name="remind_date"
                           value="{{ $reminder->remind_date }}"
                           class="form-control" required>
                </div>

                <button class="btn btn-warning">
                    <i class="bi bi-pencil-square"></i> Update
                </button>
                <a href="{{ route('reminder.index') }}" class="btn btn-secondary">
                    Batal
                </a>
            </form>
        </div>
    </div>
</div>
@endsection
